<?php
/**
 * Silence is golden.
 *
 * Prevents direct access to this directory.
 *
 * @package Modern_Hotel_Booking
 */

if (!defined('ABSPATH')) {
    exit;
}
